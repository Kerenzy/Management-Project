<?php
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../models/ProyekModel.php';
require_once __DIR__ . '/../models/TugasModel.php';
require_once __DIR__ . '/../models/LaporanModel.php';
require_once __DIR__ . '/../config/session.php';

class ReportController {
    private $proyekModel;
    private $tugasModel;
    private $laporanModel;
    
    public function __construct() {
        $this->proyekModel = new ProyekModel();
        $this->tugasModel = new TugasModel();
        $this->laporanModel = new LaporanModel();
    }
    
    private function getLogoHTML() {
        // Cek apakah file logo ada
        $logoPath = __DIR__ . '/../assets/images/logo-mms.png';
        $logoPath2 = __DIR__ . '/../assets/images/logo-mms.jpg';
        $logoPath3 = __DIR__ . '/../assets/images/logo-mms.svg';
        
        // Cek file logo (prioritas: PNG > JPG > SVG)
        if (file_exists($logoPath)) {
            return '<img src="assets/images/logo-mms.png" alt="Logo MMS" style="width: 120px; height: auto; max-height: 120px;">';
        } elseif (file_exists($logoPath2)) {
            return '<img src="assets/images/logo-mms.jpg" alt="Logo MMS" style="width: 120px; height: auto; max-height: 120px;">';
        } elseif (file_exists($logoPath3)) {
            return '<img src="assets/images/logo-mms.svg" alt="Logo MMS" style="width: 120px; height: auto; max-height: 120px;">';
        } else {
            // Placeholder jika logo belum ada
            return '<div class="logo-placeholder">MMS</div>';
        }
    }
    
    public function generateReport($proyek_id) {
        requireLogin();
        $currentRole = getCurrentUserRole();
        $currentUserId = getCurrentUserId();
        
        if ($currentRole !== 'Kepala Proyek') {
            $_SESSION['error'] = 'Hanya Kepala Proyek yang dapat generate laporan';
            header('Location: laporan.php');
            exit;
        }
        
        $proyek = $this->proyekModel->getById($proyek_id);
        
        if (!$proyek) {
            $_SESSION['error'] = 'Proyek tidak ditemukan';
            header('Location: laporan.php');
            exit;
        }
        
        if ($proyek['kepala_proyek_id'] != $currentUserId) {
            $_SESSION['error'] = 'Akses ditolak';
            header('Location: laporan.php');
            exit;
        }
        
        $tugas = $this->tugasModel->getByProyek($proyek_id);
        
        // Generate PDF using HTML
        // For production, consider using TCPDF: composer require tecnickcom/tcpdf
        $html = $this->generatePDFContent($proyek, $tugas);
        
        // Save HTML file (can be printed to PDF via browser)
        $uploadDir = __DIR__ . '/../uploads/reports/';
        if (!is_dir($uploadDir)) {
            mkdir($uploadDir, 0755, true);
        }
        
        // Save as HTML file (browser can print to PDF)
        $fileName = 'Laporan_' . preg_replace('/[^a-zA-Z0-9]/', '_', $proyek['nama_proyek']) . '_' . date('YmdHis') . '.html';
        $filePath = $uploadDir . $fileName;
        
        // Add print-to-PDF instructions in HTML
        $htmlWithInstructions = str_replace('</head>', '
            <script>
                window.onload = function() {
                    // Auto-print dialog (optional - uncomment if needed)
                    // window.print();
                }
            </script>
            <style>
                @media print {
                    body { margin: 0; }
                    .no-print { display: none; }
                }
                .print-instructions {
                    background: #f0f0f0;
                    padding: 15px;
                    margin: 20px 0;
                    border-left: 4px solid #FF2800;
                }
                .print-instructions strong {
                    color: #FF2800;
                }
            </style>
        </head>', $html);
        
        $htmlWithInstructions = str_replace('<body>', '<body>
            <div class="print-instructions no-print">
                <strong>📄 Cara Menyimpan sebagai PDF:</strong><br>
                1. Tekan <strong>Ctrl+P</strong> (Windows) atau <strong>Cmd+P</strong> (Mac)<br>
                2. Pilih "Save as PDF" sebagai destination<br>
                3. Klik "Save"<br>
                <br>
                Atau gunakan browser menu: File → Print → Save as PDF
            </div>', $htmlWithInstructions);
        
        file_put_contents($filePath, $htmlWithInstructions);
        
        // Save to database
        $this->laporanModel->create($proyek_id, $currentUserId, $fileName, $filePath);
        
        // Output HTML (can be printed to PDF via browser)
        header('Content-Type: text/html; charset=UTF-8');
        echo $htmlWithInstructions;
        exit;
    }
    
    private function generatePDFContent($proyek, $tugas) {
        // Simple HTML to PDF conversion
        // For production, consider using TCPDF or FPDF library
        $html = '
        <!DOCTYPE html>
        <html>
        <head>
            <meta charset="UTF-8">
            <style>
                body { font-family: Arial, sans-serif; }
                h1 { color: #FF2800; }
                table { width: 100%; border-collapse: collapse; margin-top: 15px; }
                th, td { border: 1px solid #ddd; padding: 6px; text-align: left; font-size: 12px; }
                th { background-color: #FF2800; color: white; }
                .letterhead { 
                    border-left: 2px solid #000; 
                    border-right: 2px solid #000; 
                    padding: 20px; 
                    margin-bottom: 20px;
                    page-break-inside: avoid;
                }
                .letterhead-content { 
                    display: flex; 
                    align-items: center; 
                    gap: 20px;
                }
                .logo-container { 
                    flex-shrink: 0;
                }
                .logo-placeholder {
                    width: 120px;
                    height: 120px;
                    background: linear-gradient(135deg, #000 0%, #000 33%, #FF2800 33%, #FF2800 66%, #000 66%);
                    border-radius: 8px;
                    display: flex;
                    align-items: center;
                    justify-content: center;
                    color: white;
                    font-weight: bold;
                    font-size: 48px;
                    letter-spacing: -2px;
                }
                .company-info { 
                    flex: 1;
                }
                .company-name { 
                    font-size: 24px; 
                    font-weight: bold; 
                    color: #000; 
                    margin: 0 0 5px 0;
                    letter-spacing: 1px;
                }
                .company-tagline { 
                    font-size: 14px; 
                    font-weight: bold; 
                    color: #FF2800; 
                    margin: 0 0 10px 0;
                    letter-spacing: 0.5px;
                }
                .company-details { 
                    font-size: 12px; 
                    color: #000; 
                    line-height: 1.6;
                    margin: 0;
                }
                .letterhead-divider { 
                    border-top: 2px solid #000; 
                    margin-top: 15px; 
                    padding-top: 10px;
                }
                .signature-section { margin-top: 40px; page-break-inside: avoid; }
                .signature-box { height: 50px; border-bottom: 1px solid #000; margin: 0 auto; width: 200px; }
                @media print {
                    .letterhead { page-break-inside: avoid; margin-bottom: 15px; }
                    .signature-section { margin-top: 30px; page-break-inside: avoid; }
                    body { margin: 10mm; }
                    table { font-size: 11px; page-break-inside: auto; }
                    tr { page-break-inside: avoid; page-break-after: auto; }
                    thead { display: table-header-group; }
                    tfoot { display: table-footer-group; }
                    h1 { font-size: 20px; margin-bottom: 10px; page-break-after: avoid; }
                    h2 { font-size: 16px; margin-bottom: 8px; page-break-after: avoid; }
                    h3 { font-size: 14px; margin-bottom: 6px; page-break-after: avoid; }
                    h4 { font-size: 12px; margin-bottom: 4px; page-break-after: avoid; }
                }
            </style>
        </head>
        <body>
            <!-- Kop Surat -->
            <div class="letterhead">
                <div class="letterhead-content">
                    <div class="logo-container">
                        ' . $this->getLogoHTML() . '
                    </div>
                    <div class="company-info">
                        <div class="company-name">PT. MULTIDAYA MITRA SINERGI</div>
                        <div class="company-tagline">PROJECT & ENGINEERING SOLUTIONS</div>
                        <div class="company-details">
                            Jl. Cipendawa Lama No.21 Kota Bekasi<br>
                            Telepon 0811-9698-237, Fax (021) 82635464<br>
                            Instagram : @multidayamitrasinergi
                        </div>
                    </div>
                </div>
                <div class="letterhead-divider"></div>
            </div>
            
            <h1>Laporan Proyek</h1>
            <h2>' . htmlspecialchars($proyek['nama_proyek']) . '</h2>
            <div style="margin: 15px 0;">
                <p style="margin: 5px 0;"><strong>Status:</strong> ' . htmlspecialchars($proyek['status']) . '</p>
                <p style="margin: 5px 0;"><strong>Progress:</strong> ' . $proyek['progress'] . '%</p>
                <p style="margin: 5px 0;"><strong>Tanggal Mulai:</strong> ' . htmlspecialchars($proyek['tanggal_mulai'] ?? '-') . '</p>
                <p style="margin: 5px 0;"><strong>Tanggal Selesai:</strong> ' . htmlspecialchars($proyek['tanggal_selesai'] ?? '-') . '</p>
                <p style="margin: 5px 0;"><strong>Owner:</strong> ' . htmlspecialchars($proyek['owner_nama'] ?? '-') . '</p>
                <p style="margin: 5px 0;"><strong>Kepala Proyek:</strong> ' . htmlspecialchars($proyek['kepala_proyek_nama'] ?? '-') . '</p>
                <p style="margin: 5px 0;"><strong>Deskripsi:</strong> ' . nl2br(htmlspecialchars($proyek['deskripsi'] ?? '-')) . '</p>
            </div>
            
            <h3>Daftar Tugas (' . count($tugas) . ' tugas)</h3>
            <table>
                <thead>
                    <tr>
                        <th>No</th>
                        <th>Nama Tugas</th>
                        <th>Status</th>
                        <th>Progress</th>
                        <th>Karyawan</th>
                        <th>Deadline</th>
                    </tr>
                </thead>
                <tbody>';
        
        $no = 1;
        foreach ($tugas as $t) {
            $statusText = $t['status'] === 'Approved' ? 'ACC' : $t['status'];
            $html .= '<tr>
                <td>' . $no++ . '</td>
                <td>' . htmlspecialchars($t['nama_tugas']) . '</td>
                <td>' . htmlspecialchars($statusText) . '</td>
                <td>' . $t['progress'] . '%</td>
                <td>' . htmlspecialchars($t['karyawan_nama'] ?? '-') . '</td>
                <td>' . htmlspecialchars($t['tanggal_deadline'] ?? '-') . '</td>
            </tr>';
        }
        
        // Calculate summary
        $totalTugas = count($tugas);
        $approvedTugas = count(array_filter($tugas, fn($t) => $t['status'] === 'Approved'));
        $completedTugas = count(array_filter($tugas, fn($t) => $t['status'] === 'Completed'));
        
        $html .= '
                </tbody>
            </table>
            <div style="margin-top: 20px; padding: 12px; background-color: #f5f5f5;">
                <h4 style="margin-top: 0;">Ringkasan</h4>
                <p style="margin: 5px 0;">Total Tugas: ' . $totalTugas . '</p>
                <p style="margin: 5px 0;">Tugas ACC (Approved): ' . $approvedTugas . '</p>
                <p style="margin: 5px 0;">Tugas Selesai (Menunggu ACC): ' . $completedTugas . '</p>
                <p style="margin: 5px 0;">Tugas Revisi: ' . count(array_filter($tugas, fn($t) => $t['status'] === 'Revisi')) . '</p>
                <p style="margin: 5px 0;"><strong>Progress Proyek: ' . $proyek['progress'] . '%</strong></p>
            </div>
            
            <div class="signature-section" style="margin-top: 30px;">
                <table style="width: 100%; border: none; margin-top: 20px;">
                    <tr>
                        <td style="width: 50%; text-align: center; border: none; padding: 10px 20px;">
                            <p style="margin-bottom: 50px; margin-top: 0;">Mengetahui,</p>
                            <p style="margin-bottom: 5px;"><strong>Kepala Proyek</strong></p>
                            <div class="signature-box" style="margin-bottom: 5px;"></div>
                            <p style="margin-top: 5px; margin-bottom: 0;">' . htmlspecialchars($proyek['kepala_proyek_nama'] ?? '-') . '</p>
                        </td>
                        <td style="width: 50%; text-align: center; border: none; padding: 10px 20px;">
                            <p style="margin-bottom: 50px; margin-top: 0;">Menyetujui,</p>
                            <p style="margin-bottom: 5px;"><strong>Owner</strong></p>
                            <div class="signature-box" style="margin-bottom: 5px;"></div>
                            <p style="margin-top: 5px; margin-bottom: 0;">' . htmlspecialchars($proyek['owner_nama'] ?? '-') . '</p>
                        </td>
                    </tr>
                </table>
            </div>
            
            <p style="margin-top: 20px; font-size: 11px; color: #666;">
                Generated on: ' . date('Y-m-d H:i:s') . ' oleh ' . htmlspecialchars($_SESSION['user_nama'] ?? 'System') . '
            </p>
        </body>
        </html>';
        
        return $html;
    }
}

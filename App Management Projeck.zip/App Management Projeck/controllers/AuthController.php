<?php
require_once __DIR__ . '/../models/UserModel.php';
require_once __DIR__ . '/../config/session.php';

class AuthController {
    private $userModel;
    
    public function __construct() {
        $this->userModel = new UserModel();
    }
    
    public function login() {
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $email = $_POST['email'] ?? '';
            $password = $_POST['password'] ?? '';
            
            if (empty($email) || empty($password)) {
                $_SESSION['error'] = 'Email dan password harus diisi';
                header('Location: login.php');
                exit;
            }
            
            $user = $this->userModel->login($email, $password);
            
            if ($user) {
                $_SESSION['user_id'] = $user['id'];
                $_SESSION['user_nama'] = $user['nama'];
                $_SESSION['user_email'] = $user['email'];
                $_SESSION['user_role'] = $user['role'];
                
                header('Location: index.php');
                exit;
            } else {
                $_SESSION['error'] = 'Email atau password salah';
                header('Location: login.php');
                exit;
            }
        }
    }
    
    public function register() {
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $nama = $_POST['nama'] ?? '';
            $email = $_POST['email'] ?? '';
            $password = $_POST['password'] ?? '';
            $confirm_password = $_POST['confirm_password'] ?? '';
            $role = $_POST['role'] ?? 'Karyawan';
            
            if (empty($nama) || empty($email) || empty($password)) {
                $_SESSION['error'] = 'Semua field harus diisi';
                header('Location: register.php');
                exit;
            }
            
            if ($password !== $confirm_password) {
                $_SESSION['error'] = 'Password dan konfirmasi password tidak cocok';
                header('Location: register.php');
                exit;
            }
            
            if ($this->userModel->emailExists($email)) {
                $_SESSION['error'] = 'Email sudah terdaftar';
                header('Location: register.php');
                exit;
            }
            
            $userId = $this->userModel->register($nama, $email, $password, $role);
            
            if ($userId) {
                $_SESSION['success'] = 'Registrasi berhasil. Silakan login.';
                header('Location: login.php');
                exit;
            } else {
                $_SESSION['error'] = 'Registrasi gagal';
                header('Location: register.php');
                exit;
            }
        }
    }
    
    public function logout() {
        session_destroy();
        header('Location: login.php');
        exit;
    }
}

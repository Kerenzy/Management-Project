<?php
require_once __DIR__ . '/../config/database.php';

class DokumentasiModel {
    private $conn;
    
    public function __construct() {
        $this->conn = getConnection();
    }
    
    public function create($tugas_id, $nama_file, $path_file, $ukuran_file, $uploaded_by) {
        $stmt = $this->conn->prepare("INSERT INTO dokumentasi (tugas_id, nama_file, path_file, ukuran_file, uploaded_by) VALUES (?, ?, ?, ?, ?)");
        $stmt->bind_param("issii", $tugas_id, $nama_file, $path_file, $ukuran_file, $uploaded_by);
        
        return $stmt->execute();
    }
    
    public function getByTugas($tugas_id) {
        $stmt = $this->conn->prepare("SELECT d.*, u.nama as uploaded_by_nama 
                                       FROM dokumentasi d 
                                       LEFT JOIN users u ON d.uploaded_by = u.id 
                                       WHERE d.tugas_id = ?
                                       ORDER BY d.created_at DESC");
        $stmt->bind_param("i", $tugas_id);
        $stmt->execute();
        $result = $stmt->get_result();
        
        $dokumentasi = [];
        while ($row = $result->fetch_assoc()) {
            $dokumentasi[] = $row;
        }
        
        return $dokumentasi;
    }
    
    public function getById($id) {
        $stmt = $this->conn->prepare("SELECT d.*, u.nama as uploaded_by_nama 
                                       FROM dokumentasi d 
                                       LEFT JOIN users u ON d.uploaded_by = u.id 
                                       WHERE d.id = ?");
        $stmt->bind_param("i", $id);
        $stmt->execute();
        $result = $stmt->get_result();
        
        return $result->fetch_assoc();
    }
    
    public function delete($id) {
        $stmt = $this->conn->prepare("SELECT path_file FROM dokumentasi WHERE id = ?");
        $stmt->bind_param("i", $id);
        $stmt->execute();
        $result = $stmt->get_result();
        $file = $result->fetch_assoc();
        
        if ($file && file_exists($file['path_file'])) {
            unlink($file['path_file']);
        }
        
        $stmt = $this->conn->prepare("DELETE FROM dokumentasi WHERE id = ?");
        $stmt->bind_param("i", $id);
        
        return $stmt->execute();
    }
    
    public function __destruct() {
        if ($this->conn) {
            closeConnection($this->conn);
        }
    }
}

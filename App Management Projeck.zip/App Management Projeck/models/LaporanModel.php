<?php
require_once __DIR__ . '/../config/database.php';

class LaporanModel {
    private $conn;
    
    public function __construct() {
        $this->conn = getConnection();
    }
    
    public function create($proyek_id, $kepala_proyek_id, $nama_file, $path_file) {
        $stmt = $this->conn->prepare("INSERT INTO laporan_proyek (proyek_id, kepala_proyek_id, nama_file, path_file) VALUES (?, ?, ?, ?)");
        $stmt->bind_param("iiss", $proyek_id, $kepala_proyek_id, $nama_file, $path_file);
        
        return $stmt->execute();
    }
    
    public function getByProyek($proyek_id) {
        $stmt = $this->conn->prepare("SELECT l.*, u.nama as kepala_proyek_nama 
                                       FROM laporan_proyek l 
                                       LEFT JOIN users u ON l.kepala_proyek_id = u.id 
                                       WHERE l.proyek_id = ?
                                       ORDER BY l.created_at DESC");
        $stmt->bind_param("i", $proyek_id);
        $stmt->execute();
        $result = $stmt->get_result();
        
        $laporan = [];
        while ($row = $result->fetch_assoc()) {
            $laporan[] = $row;
        }
        
        return $laporan;
    }
    
    public function getAll() {
        $sql = "SELECT l.*, p.nama_proyek, u.nama as kepala_proyek_nama 
                FROM laporan_proyek l 
                LEFT JOIN proyek p ON l.proyek_id = p.id 
                LEFT JOIN users u ON l.kepala_proyek_id = u.id 
                ORDER BY l.created_at DESC";
        $result = $this->conn->query($sql);
        
        $laporan = [];
        while ($row = $result->fetch_assoc()) {
            $laporan[] = $row;
        }
        
        return $laporan;
    }
    
    public function getById($id) {
        $stmt = $this->conn->prepare("SELECT l.*, p.nama_proyek, u.nama as kepala_proyek_nama 
                                       FROM laporan_proyek l 
                                       LEFT JOIN proyek p ON l.proyek_id = p.id 
                                       LEFT JOIN users u ON l.kepala_proyek_id = u.id 
                                       WHERE l.id = ?");
        $stmt->bind_param("i", $id);
        $stmt->execute();
        $result = $stmt->get_result();
        
        return $result->fetch_assoc();
    }
    
    public function __destruct() {
        if ($this->conn) {
            closeConnection($this->conn);
        }
    }
}

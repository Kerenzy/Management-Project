<?php
require_once __DIR__ . '/../config/database.php';

class ProyekModel {
    private $conn;
    
    public function __construct() {
        $this->conn = getConnection();
    }
    
    public function create($nama_proyek, $deskripsi, $owner_id, $kepala_proyek_id, $tanggal_mulai, $tanggal_selesai) {
        $stmt = $this->conn->prepare("INSERT INTO proyek (nama_proyek, deskripsi, owner_id, kepala_proyek_id, tanggal_mulai, tanggal_selesai) VALUES (?, ?, ?, ?, ?, ?)");
        $stmt->bind_param("ssiiss", $nama_proyek, $deskripsi, $owner_id, $kepala_proyek_id, $tanggal_mulai, $tanggal_selesai);
        
        return $stmt->execute();
    }
    
    public function getAll() {
        $sql = "SELECT p.*, u1.nama as owner_nama, u2.nama as kepala_proyek_nama 
                FROM proyek p 
                LEFT JOIN users u1 ON p.owner_id = u1.id 
                LEFT JOIN users u2 ON p.kepala_proyek_id = u2.id 
                ORDER BY p.created_at DESC";
        $result = $this->conn->query($sql);
        
        $proyek = [];
        while ($row = $result->fetch_assoc()) {
            $proyek[] = $row;
        }
        
        return $proyek;
    }
    
    public function getById($id) {
        $stmt = $this->conn->prepare("SELECT p.*, u1.nama as owner_nama, u2.nama as kepala_proyek_nama 
                                       FROM proyek p 
                                       LEFT JOIN users u1 ON p.owner_id = u1.id 
                                       LEFT JOIN users u2 ON p.kepala_proyek_id = u2.id 
                                       WHERE p.id = ?");
        $stmt->bind_param("i", $id);
        $stmt->execute();
        $result = $stmt->get_result();
        
        return $result->fetch_assoc();
    }
    
    public function getByOwner($owner_id) {
        $stmt = $this->conn->prepare("SELECT p.*, u1.nama as owner_nama, u2.nama as kepala_proyek_nama 
                                       FROM proyek p 
                                       LEFT JOIN users u1 ON p.owner_id = u1.id 
                                       LEFT JOIN users u2 ON p.kepala_proyek_id = u2.id 
                                       WHERE p.owner_id = ?
                                       ORDER BY p.created_at DESC");
        $stmt->bind_param("i", $owner_id);
        $stmt->execute();
        $result = $stmt->get_result();
        
        $proyek = [];
        while ($row = $result->fetch_assoc()) {
            $proyek[] = $row;
        }
        
        return $proyek;
    }
    
    public function getByKepalaProyek($kepala_proyek_id) {
        $stmt = $this->conn->prepare("SELECT p.*, u1.nama as owner_nama, u2.nama as kepala_proyek_nama 
                                       FROM proyek p 
                                       LEFT JOIN users u1 ON p.owner_id = u1.id 
                                       LEFT JOIN users u2 ON p.kepala_proyek_id = u2.id 
                                       WHERE p.kepala_proyek_id = ?
                                       ORDER BY p.created_at DESC");
        $stmt->bind_param("i", $kepala_proyek_id);
        $stmt->execute();
        $result = $stmt->get_result();
        
        $proyek = [];
        while ($row = $result->fetch_assoc()) {
            $proyek[] = $row;
        }
        
        return $proyek;
    }
    
    public function update($id, $nama_proyek, $deskripsi, $status, $progress, $tanggal_mulai, $tanggal_selesai) {
        $stmt = $this->conn->prepare("UPDATE proyek SET nama_proyek = ?, deskripsi = ?, status = ?, progress = ?, tanggal_mulai = ?, tanggal_selesai = ? WHERE id = ?");
        $stmt->bind_param("sssissi", $nama_proyek, $deskripsi, $status, $progress, $tanggal_mulai, $tanggal_selesai, $id);
        
        return $stmt->execute();
    }
    
    public function updateKepalaProyek($id, $kepala_proyek_id) {
        if ($kepala_proyek_id === null || $kepala_proyek_id === '') {
            $stmt = $this->conn->prepare("UPDATE proyek SET kepala_proyek_id = NULL WHERE id = ?");
            $stmt->bind_param("i", $id);
        } else {
            $stmt = $this->conn->prepare("UPDATE proyek SET kepala_proyek_id = ? WHERE id = ?");
            $stmt->bind_param("ii", $kepala_proyek_id, $id);
        }
        
        return $stmt->execute();
    }
    
    public function updateProgress($id) {
        // Calculate progress based on approved tasks only (as per spec: completed tasks / total tasks * 100)
        $stmt = $this->conn->prepare("SELECT COUNT(*) as total, SUM(CASE WHEN status = 'Approved' THEN 1 ELSE 0 END) as completed 
                                       FROM tugas WHERE proyek_id = ?");
        $stmt->bind_param("i", $id);
        $stmt->execute();
        $result = $stmt->get_result();
        $data = $result->fetch_assoc();
        
        if ($data['total'] > 0) {
            $progress = round(($data['completed'] / $data['total']) * 100);
        } else {
            $progress = 0;
        }
        
        $stmt = $this->conn->prepare("UPDATE proyek SET progress = ? WHERE id = ?");
        $stmt->bind_param("ii", $progress, $id);
        $updateResult = $stmt->execute();
        
        // Auto-update project status based on progress
        $this->updateProjectStatus($id);
        
        return $updateResult;
    }
    
    public function updateProjectStatus($id) {
        // Get project and tasks
        $proyek = $this->getById($id);
        if (!$proyek) return false;
        
        // Count tasks
        $stmt = $this->conn->prepare("SELECT COUNT(*) as total, SUM(CASE WHEN status = 'Approved' THEN 1 ELSE 0 END) as approved 
                                       FROM tugas WHERE proyek_id = ?");
        $stmt->bind_param("i", $id);
        $stmt->execute();
        $result = $stmt->get_result();
        $data = $result->fetch_assoc();
        
        $newStatus = $proyek['status'];
        
        // If all tasks are approved, set to "In Progress" (waiting for Owner approval)
        // DO NOT auto-set to "Completed" - Owner must approve project first
        if ($data['total'] > 0 && $data['approved'] == $data['total'] && $proyek['status'] != 'Completed') {
            // Only set to In Progress if not already Completed (Owner approved)
            // Don't change from Completed back to In Progress
            if ($proyek['status'] != 'Completed') {
                $newStatus = 'In Progress';
            }
        } 
        // If project has tasks and progress > 0 but not all approved, set to In Progress
        elseif ($data['total'] > 0 && $data['approved'] > 0 && $proyek['status'] == 'Planning') {
            $newStatus = 'In Progress';
        }
        
        // Only update if status changed
        if ($newStatus != $proyek['status']) {
            $stmt = $this->conn->prepare("UPDATE proyek SET status = ? WHERE id = ?");
            $stmt->bind_param("si", $newStatus, $id);
            return $stmt->execute();
        }
        
        return true;
    }
    
    /**
     * Owner approves project - set status to Completed
     */
    public function approveByOwner($id) {
        // Check if all tasks are approved
        $stmt = $this->conn->prepare("SELECT COUNT(*) as total, SUM(CASE WHEN status = 'Approved' THEN 1 ELSE 0 END) as approved 
                                       FROM tugas WHERE proyek_id = ?");
        $stmt->bind_param("i", $id);
        $stmt->execute();
        $result = $stmt->get_result();
        $data = $result->fetch_assoc();
        
        // Only allow approval if all tasks are approved
        if ($data['total'] > 0 && $data['approved'] == $data['total']) {
            $stmt = $this->conn->prepare("UPDATE proyek SET status = 'Completed' WHERE id = ?");
            $stmt->bind_param("i", $id);
            return $stmt->execute();
        }
        
        return false; // Not all tasks approved yet
    }
    
    public function delete($id) {
        $stmt = $this->conn->prepare("DELETE FROM proyek WHERE id = ?");
        $stmt->bind_param("i", $id);
        
        return $stmt->execute();
    }
    
    public function getConnection() {
        return $this->conn;
    }
    
    public function __destruct() {
        if ($this->conn) {
            closeConnection($this->conn);
        }
    }
}

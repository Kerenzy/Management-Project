<?php
require_once __DIR__ . '/../config/database.php';

class UserModel {
    private $conn;
    
    public function __construct() {
        $this->conn = getConnection();
    }
    
    public function login($email, $password) {
        $stmt = $this->conn->prepare("SELECT id, nama, email, password, role FROM users WHERE email = ?");
        $stmt->bind_param("s", $email);
        $stmt->execute();
        $result = $stmt->get_result();
        
        if ($result->num_rows === 1) {
            $user = $result->fetch_assoc();
            if (password_verify($password, $user['password'])) {
                return $user;
            }
        }
        
        return false;
    }
    
    public function register($nama, $email, $password, $role) {
        $hashedPassword = password_hash($password, PASSWORD_DEFAULT);
        $stmt = $this->conn->prepare("INSERT INTO users (nama, email, password, role) VALUES (?, ?, ?, ?)");
        $stmt->bind_param("ssss", $nama, $email, $hashedPassword, $role);
        
        if ($stmt->execute()) {
            return $this->conn->insert_id;
        }
        
        return false;
    }
    
    public function getUserById($id) {
        $stmt = $this->conn->prepare("SELECT id, nama, email, role FROM users WHERE id = ?");
        $stmt->bind_param("i", $id);
        $stmt->execute();
        $result = $stmt->get_result();
        
        return $result->fetch_assoc();
    }
    
    public function getAllUsers($role = null) {
        if ($role) {
            $stmt = $this->conn->prepare("SELECT id, nama, email, role FROM users WHERE role = ?");
            $stmt->bind_param("s", $role);
        } else {
            $stmt = $this->conn->prepare("SELECT id, nama, email, role FROM users");
        }
        
        $stmt->execute();
        $result = $stmt->get_result();
        
        $users = [];
        while ($row = $result->fetch_assoc()) {
            $users[] = $row;
        }
        
        return $users;
    }
    
    public function emailExists($email, $excludeUserId = null) {
        if ($excludeUserId) {
            $stmt = $this->conn->prepare("SELECT id FROM users WHERE email = ? AND id != ?");
            $stmt->bind_param("si", $email, $excludeUserId);
        } else {
        $stmt = $this->conn->prepare("SELECT id FROM users WHERE email = ?");
        $stmt->bind_param("s", $email);
        }
        $stmt->execute();
        $result = $stmt->get_result();
        
        return $result->num_rows > 0;
    }
    
    public function update($id, $nama, $email, $role, $password = null) {
        $allowedRoles = ['Owner', 'Kepala Proyek', 'Karyawan'];
        if (!in_array($role, $allowedRoles)) {
            return false;
        }
        
        // Check if email already exists (excluding current user)
        if ($this->emailExists($email, $id)) {
            return false; // Email already exists
        }
        
        if ($password) {
            // Update with password
            $hashedPassword = password_hash($password, PASSWORD_DEFAULT);
            $stmt = $this->conn->prepare("UPDATE users SET nama = ?, email = ?, role = ?, password = ? WHERE id = ?");
            $stmt->bind_param("ssssi", $nama, $email, $role, $hashedPassword, $id);
        } else {
            // Update without password
            $stmt = $this->conn->prepare("UPDATE users SET nama = ?, email = ?, role = ? WHERE id = ?");
            $stmt->bind_param("sssi", $nama, $email, $role, $id);
        }
        
        return $stmt->execute();
    }
    
    public function updateRole($id, $role) {
        $allowedRoles = ['Owner', 'Kepala Proyek', 'Karyawan'];
        if (!in_array($role, $allowedRoles)) {
            return false;
        }
        
        $stmt = $this->conn->prepare("UPDATE users SET role = ? WHERE id = ?");
        $stmt->bind_param("si", $role, $id);
        
        return $stmt->execute();
    }
    
    public function delete($id) {
        $stmt = $this->conn->prepare("DELETE FROM users WHERE id = ?");
        $stmt->bind_param("i", $id);
        
        return $stmt->execute();
    }
    
    public function __destruct() {
        if ($this->conn) {
            closeConnection($this->conn);
        }
    }
}

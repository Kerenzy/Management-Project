<?php
require_once __DIR__ . '/../config/database.php';

class TugasModel {
    private $conn;
    
    public function __construct() {
        $this->conn = getConnection();
    }
    
    public function create($proyek_id, $nama_tugas, $deskripsi, $kepala_proyek_id, $karyawan_id, $tanggal_deadline) {
        $stmt = $this->conn->prepare("INSERT INTO tugas (proyek_id, nama_tugas, deskripsi, kepala_proyek_id, karyawan_id, tanggal_deadline) VALUES (?, ?, ?, ?, ?, ?)");
        $stmt->bind_param("issiis", $proyek_id, $nama_tugas, $deskripsi, $kepala_proyek_id, $karyawan_id, $tanggal_deadline);
        
        return $stmt->execute();
    }
    
    public function getAll() {
        $sql = "SELECT t.*, p.nama_proyek, u1.nama as kepala_proyek_nama, u2.nama as karyawan_nama 
                FROM tugas t 
                LEFT JOIN proyek p ON t.proyek_id = p.id 
                LEFT JOIN users u1 ON t.kepala_proyek_id = u1.id 
                LEFT JOIN users u2 ON t.karyawan_id = u2.id 
                ORDER BY t.created_at DESC";
        $result = $this->conn->query($sql);
        
        $tugas = [];
        while ($row = $result->fetch_assoc()) {
            $tugas[] = $row;
        }
        
        return $tugas;
    }
    
    public function getById($id) {
        $stmt = $this->conn->prepare("SELECT t.*, p.nama_proyek, u1.nama as kepala_proyek_nama, u2.nama as karyawan_nama 
                                       FROM tugas t 
                                       LEFT JOIN proyek p ON t.proyek_id = p.id 
                                       LEFT JOIN users u1 ON t.kepala_proyek_id = u1.id 
                                       LEFT JOIN users u2 ON t.karyawan_id = u2.id 
                                       WHERE t.id = ?");
        $stmt->bind_param("i", $id);
        $stmt->execute();
        $result = $stmt->get_result();
        
        return $result->fetch_assoc();
    }
    
    public function getByProyek($proyek_id) {
        $stmt = $this->conn->prepare("SELECT t.*, p.nama_proyek, u1.nama as kepala_proyek_nama, u2.nama as karyawan_nama 
                                       FROM tugas t 
                                       LEFT JOIN proyek p ON t.proyek_id = p.id 
                                       LEFT JOIN users u1 ON t.kepala_proyek_id = u1.id 
                                       LEFT JOIN users u2 ON t.karyawan_id = u2.id 
                                       WHERE t.proyek_id = ?
                                       ORDER BY t.created_at DESC");
        $stmt->bind_param("i", $proyek_id);
        $stmt->execute();
        $result = $stmt->get_result();
        
        $tugas = [];
        while ($row = $result->fetch_assoc()) {
            $tugas[] = $row;
        }
        
        return $tugas;
    }
    
    public function getByKaryawan($karyawan_id) {
        $stmt = $this->conn->prepare("SELECT t.*, p.nama_proyek, u1.nama as kepala_proyek_nama, u2.nama as karyawan_nama 
                                       FROM tugas t 
                                       LEFT JOIN proyek p ON t.proyek_id = p.id 
                                       LEFT JOIN users u1 ON t.kepala_proyek_id = u1.id 
                                       LEFT JOIN users u2 ON t.karyawan_id = u2.id 
                                       WHERE t.karyawan_id = ?
                                       ORDER BY t.created_at DESC");
        $stmt->bind_param("i", $karyawan_id);
        $stmt->execute();
        $result = $stmt->get_result();
        
        $tugas = [];
        while ($row = $result->fetch_assoc()) {
            $tugas[] = $row;
        }
        
        return $tugas;
    }
    
    public function getByKepalaProyek($kepala_proyek_id) {
        $stmt = $this->conn->prepare("SELECT t.*, p.nama_proyek, u1.nama as kepala_proyek_nama, u2.nama as karyawan_nama 
                                       FROM tugas t 
                                       LEFT JOIN proyek p ON t.proyek_id = p.id 
                                       LEFT JOIN users u1 ON t.kepala_proyek_id = u1.id 
                                       LEFT JOIN users u2 ON t.karyawan_id = u2.id 
                                       WHERE t.kepala_proyek_id = ?
                                       ORDER BY t.created_at DESC");
        $stmt->bind_param("i", $kepala_proyek_id);
        $stmt->execute();
        $result = $stmt->get_result();
        
        $tugas = [];
        while ($row = $result->fetch_assoc()) {
            $tugas[] = $row;
        }
        
        return $tugas;
    }
    
    public function updateStatus($id, $status) {
        // If status is Rejected, change it to Revisi (as per spec: ACC or Revisi)
        if ($status === 'Rejected') {
            $status = 'Revisi';
        }
        
        $stmt = $this->conn->prepare("UPDATE tugas SET status = ? WHERE id = ?");
        $stmt->bind_param("si", $status, $id);
        
        return $stmt->execute();
    }
    
    public function getProyekId($tugas_id) {
        $stmt = $this->conn->prepare("SELECT proyek_id FROM tugas WHERE id = ?");
        $stmt->bind_param("i", $tugas_id);
        $stmt->execute();
        $result = $stmt->get_result();
        $row = $result->fetch_assoc();
        return $row ? $row['proyek_id'] : null;
    }
    
    public function updateProgress($id, $progress) {
        $stmt = $this->conn->prepare("UPDATE tugas SET progress = ? WHERE id = ?");
        $stmt->bind_param("ii", $progress, $id);
        
        return $stmt->execute();
    }
    
    public function delete($id) {
        $stmt = $this->conn->prepare("DELETE FROM tugas WHERE id = ?");
        $stmt->bind_param("i", $id);
        
        return $stmt->execute();
    }
    
    public function __destruct() {
        if ($this->conn) {
            closeConnection($this->conn);
        }
    }
}

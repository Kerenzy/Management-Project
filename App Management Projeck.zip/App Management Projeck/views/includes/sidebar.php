<?php
$currentRole = $_SESSION['user_role'] ?? '';
$currentPage = basename($_SERVER['PHP_SELF']);
?>

<div class="sidebar">
    <ul class="sidebar-menu">
        <li>
            <a href="index.php" class="<?php echo $currentPage === 'index.php' ? 'active' : ''; ?>">Dashboard</a>
        </li>
        
        <?php if ($currentRole === 'Owner'): ?>
            <li><a href="proyek.php" class="<?php echo $currentPage === 'proyek.php' ? 'active' : ''; ?>">Semua Proyek</a></li>
            <li><a href="proyek_tambah.php" class="<?php echo $currentPage === 'proyek_tambah.php' ? 'active' : ''; ?>">Tambah Proyek</a></li>
            <li><a href="tugas.php" class="<?php echo $currentPage === 'tugas.php' ? 'active' : ''; ?>">Semua Tugas</a></li>
            <li><a href="users.php" class="<?php echo $currentPage === 'users.php' ? 'active' : ''; ?>">Manajemen User</a></li>
            <li><a href="laporan.php" class="<?php echo $currentPage === 'laporan.php' ? 'active' : ''; ?>">Semua Laporan</a></li>
        <?php endif; ?>
        
        <?php if ($currentRole === 'Kepala Proyek'): ?>
            <li><a href="proyek.php" class="<?php echo $currentPage === 'proyek.php' ? 'active' : ''; ?>">Proyek Saya</a></li>
            <li><a href="tugas.php" class="<?php echo $currentPage === 'tugas.php' ? 'active' : ''; ?>">Tugas</a></li>
            <li><a href="tugas_tambah.php" class="<?php echo $currentPage === 'tugas_tambah.php' ? 'active' : ''; ?>">Tambah Tugas</a></li>
            <li><a href="laporan.php" class="<?php echo $currentPage === 'laporan.php' ? 'active' : ''; ?>">Laporan</a></li>
        <?php endif; ?>
        
        <?php if ($currentRole === 'Karyawan'): ?>
            <li><a href="tugas.php" class="<?php echo $currentPage === 'tugas.php' ? 'active' : ''; ?>">Tugas Saya</a></li>
        <?php endif; ?>
    </ul>
</div>


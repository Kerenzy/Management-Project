<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $pageTitle ?? 'MMS Project Management'; ?></title>
    <link rel="stylesheet" href="assets/css/style.css">
    <?php if (isset($pageTitle) && $pageTitle === 'Dashboard'): ?>
    <meta http-equiv="refresh" content="300">
    <?php endif; ?>
</head>
<body>
    <nav class="navbar">
        <a href="index.php" class="navbar-brand">MMS Project Management</a>
        <div class="navbar-menu">
            <span style="color: white; margin-right: 1rem;"><?php echo $_SESSION['user_nama'] ?? ''; ?> (<?php echo $_SESSION['user_role'] ?? ''; ?>)</span>
            <a href="index.php">Dashboard</a>
            <a href="logout.php">Logout</a>
        </div>
    </nav>


-- Database: mms_project
-- Create database
CREATE DATABASE IF NOT EXISTS mms_project CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE mms_project;

-- Table: users
CREATE TABLE IF NOT EXISTS users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nama VARCHAR(100) NOT NULL,
    email VARCHAR(100) UNIQUE NOT NULL,
    password VARCHAR(255) NOT NULL,
    role ENUM('Owner', 'Kepala Proyek', 'Karyawan') NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Table: proyek
CREATE TABLE IF NOT EXISTS proyek (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nama_proyek VARCHAR(200) NOT NULL,
    deskripsi TEXT,
    owner_id INT NOT NULL,
    kepala_proyek_id INT,
    status ENUM('Planning', 'In Progress', 'On Hold', 'Completed', 'Cancelled') DEFAULT 'Planning',
    tanggal_mulai DATE,
    tanggal_selesai DATE,
    progress INT DEFAULT 0,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (owner_id) REFERENCES users(id) ON DELETE CASCADE,
    FOREIGN KEY (kepala_proyek_id) REFERENCES users(id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Table: tugas
CREATE TABLE IF NOT EXISTS tugas (
    id INT AUTO_INCREMENT PRIMARY KEY,
    proyek_id INT NOT NULL,
    nama_tugas VARCHAR(200) NOT NULL,
    deskripsi TEXT,
    kepala_proyek_id INT NOT NULL,
    karyawan_id INT,
    status ENUM('Pending', 'In Progress', 'Completed', 'Approved', 'Rejected', 'Revisi') DEFAULT 'Pending',
    progress INT DEFAULT 0,
    tanggal_deadline DATE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (proyek_id) REFERENCES proyek(id) ON DELETE CASCADE,
    FOREIGN KEY (kepala_proyek_id) REFERENCES users(id) ON DELETE CASCADE,
    FOREIGN KEY (karyawan_id) REFERENCES users(id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Table: dokumentasi
CREATE TABLE IF NOT EXISTS dokumentasi (
    id INT AUTO_INCREMENT PRIMARY KEY,
    tugas_id INT NOT NULL,
    nama_file VARCHAR(255) NOT NULL,
    path_file VARCHAR(500) NOT NULL,
    ukuran_file INT,
    uploaded_by INT NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (tugas_id) REFERENCES tugas(id) ON DELETE CASCADE,
    FOREIGN KEY (uploaded_by) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Table: laporan_proyek
CREATE TABLE IF NOT EXISTS laporan_proyek (
    id INT AUTO_INCREMENT PRIMARY KEY,
    proyek_id INT NOT NULL,
    kepala_proyek_id INT NOT NULL,
    nama_file VARCHAR(255) NOT NULL,
    path_file VARCHAR(500) NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (proyek_id) REFERENCES proyek(id) ON DELETE CASCADE,
    FOREIGN KEY (kepala_proyek_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Insert default admin user (password: admin123)
-- Optional seed Owner with full access (default password: password)
INSERT INTO users (nama, email, password, role) VALUES
('Owner Utama', 'owner@mms.com', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'Owner');


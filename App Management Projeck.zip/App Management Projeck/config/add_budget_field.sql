-- Add budget field to proyek table
ALTER TABLE proyek ADD COLUMN IF NOT EXISTS budget DECIMAL(15,2) DEFAULT NULL AFTER deskripsi;

-- Update tugas status enum to include 'Revisi'
ALTER TABLE tugas MODIFY COLUMN status ENUM('Pending', 'In Progress', 'Completed', 'Approved', 'Rejected', 'Revisi') DEFAULT 'Pending';


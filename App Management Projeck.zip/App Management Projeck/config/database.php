<?php
// Database Configuration
define('DB_HOST', '127.0.0.1');
define('DB_USER', 'root');
define('DB_PASS', '');
define('DB_NAME', 'mms_project');

// Create connection with better error handling
function getConnection() {
    $conn = @new mysqli(DB_HOST, DB_USER, DB_PASS, DB_NAME);
    
    if ($conn->connect_error) {
        // Better error message
        $errorMsg = "Connection failed: " . $conn->connect_error;
        
        // Check if MySQL is running
        if (strpos($conn->connect_error, 'Can\'t connect') !== false) {
            $errorMsg .= "\n\n⚠️ MySQL Server tidak berjalan!\n";
            $errorMsg .= "Solusi:\n";
            $errorMsg .= "1. Buka XAMPP Control Panel\n";
            $errorMsg .= "2. Start MySQL service\n";
            $errorMsg .= "3. Atau jalankan: /Applications/XAMPP/xamppfiles/xampp startmysql\n";
        } elseif (strpos($conn->connect_error, 'Access denied') !== false) {
            $errorMsg .= "\n\n⚠️ Password MySQL salah atau user tidak punya akses!\n";
            $errorMsg .= "Solusi:\n";
            $errorMsg .= "1. Cek password di config/database.php\n";
            $errorMsg .= "2. Atau reset password MySQL\n";
        } elseif (strpos($conn->connect_error, 'Unknown database') !== false) {
            $errorMsg .= "\n\n⚠️ Database 'mms_project' tidak ditemukan!\n";
            $errorMsg .= "Solusi: Jalankan import_database.php atau config/database.sql\n";
        }
        
        die($errorMsg);
    }
    
    $conn->set_charset("utf8");
    return $conn;
}

// Close connection
function closeConnection($conn) {
    if ($conn) {
    $conn->close();
}
}

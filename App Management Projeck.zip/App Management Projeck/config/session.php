<?php
// Session Configuration
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Check if user is logged in
function isLoggedIn() {
    return isset($_SESSION['user_id']) && isset($_SESSION['user_role']);
}

// Check user role
function checkRole($allowedRoles) {
    if (!isLoggedIn()) {
        header('Location: login.php');
        exit;
    }
    
    if (!in_array($_SESSION['user_role'], $allowedRoles)) {
        header('Location: index.php');
        exit;
    }
}

// Redirect if not logged in
function requireLogin() {
    if (!isLoggedIn()) {
        header('Location: login.php');
        exit;
    }
}

// Get current user ID
function getCurrentUserId() {
    return $_SESSION['user_id'] ?? null;
}

// Get current user role
function getCurrentUserRole() {
    return $_SESSION['user_role'] ?? null;
}
